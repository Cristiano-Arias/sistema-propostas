from flask import Blueprint, request, jsonify
from datetime import datetime
import json
import os

propostas_bp = Blueprint('propostas', __name__)

# Diretórios para armazenar dados
FORNECEDOR_DIR = '/home/ubuntu/portal-propostas-backend/data/fornecedor'
COMPRADOR_DIR = '/home/ubuntu/portal-propostas-backend/data/comprador'

# Criar diretórios se não existirem
os.makedirs(FORNECEDOR_DIR, exist_ok=True)
os.makedirs(COMPRADOR_DIR, exist_ok=True)

@propostas_bp.route('/api/propostas/enviar', methods=['POST'])
def enviar_proposta():
    try:
        dados = request.get_json()
        
        if not dados:
            return jsonify({'erro': 'Dados não fornecidos'}), 400
        
        # Gerar protocolo único
        timestamp = datetime.now()
        protocolo = f"PROP-{timestamp.strftime('%Y%m%d%H%M%S')}-{timestamp.microsecond}"
        
        # Adicionar protocolo e timestamp aos dados
        dados['protocolo'] = protocolo
        dados['dataEnvio'] = timestamp.isoformat()
        dados['status'] = 'enviado'
        
        # Salvar no módulo Fornecedor
        arquivo_fornecedor = os.path.join(FORNECEDOR_DIR, f'{protocolo}.json')
        with open(arquivo_fornecedor, 'w', encoding='utf-8') as f:
            json.dump(dados, f, ensure_ascii=False, indent=2)
        
        # Enviar para módulo Comprador
        dados_comprador = {
            'protocolo': protocolo,
            'dataRecebimento': timestamp.isoformat(),
            'status': 'recebido',
            'fornecedor': {
                'razaoSocial': dados.get('dadosCadastrais', {}).get('razaoSocial'),
                'cnpj': dados.get('dadosCadastrais', {}).get('cnpj'),
                'email': dados.get('dadosCadastrais', {}).get('email')
            },
            'processo': dados.get('processo', {}),
            'valorTotal': dados.get('propostaComercial', {}).get('valorTotal'),
            'prazoExecucao': dados.get('resumo', {}).get('prazoExecucao'),
            'dadosCompletos': dados  # Dados completos para análise
        }
        
        arquivo_comprador = os.path.join(COMPRADOR_DIR, f'{protocolo}.json')
        with open(arquivo_comprador, 'w', encoding='utf-8') as f:
            json.dump(dados_comprador, f, ensure_ascii=False, indent=2)
        
        # Log da operação
        log_entry = {
            'timestamp': timestamp.isoformat(),
            'protocolo': protocolo,
            'acao': 'proposta_enviada',
            'fornecedor': dados.get('dadosCadastrais', {}).get('razaoSocial'),
            'processo': dados.get('processo', {}).get('numero'),
            'valor': dados.get('propostaComercial', {}).get('valorTotal')
        }
        
        log_file = '/home/ubuntu/portal-propostas-backend/data/log_propostas.json'
        logs = []
        if os.path.exists(log_file):
            with open(log_file, 'r', encoding='utf-8') as f:
                logs = json.load(f)
        
        logs.append(log_entry)
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(logs, f, ensure_ascii=False, indent=2)
        
        return jsonify({
            'sucesso': True,
            'protocolo': protocolo,
            'dataEnvio': timestamp.isoformat(),
            'mensagem': 'Proposta enviada com sucesso'
        })
        
    except Exception as e:
        return jsonify({
            'erro': f'Erro interno do servidor: {str(e)}'
        }), 500

@propostas_bp.route('/api/propostas/status/<protocolo>', methods=['GET'])
def consultar_status(protocolo):
    try:
        arquivo_fornecedor = os.path.join(FORNECEDOR_DIR, f'{protocolo}.json')
        
        if not os.path.exists(arquivo_fornecedor):
            return jsonify({'erro': 'Proposta não encontrada'}), 404
        
        with open(arquivo_fornecedor, 'r', encoding='utf-8') as f:
            dados = json.load(f)
        
        return jsonify({
            'protocolo': dados.get('protocolo'),
            'status': dados.get('status'),
            'dataEnvio': dados.get('dataEnvio'),
            'fornecedor': dados.get('dadosCadastrais', {}).get('razaoSocial'),
            'processo': dados.get('processo', {}).get('numero'),
            'valorTotal': dados.get('propostaComercial', {}).get('valorTotal')
        })
        
    except Exception as e:
        return jsonify({
            'erro': f'Erro ao consultar status: {str(e)}'
        }), 500

@propostas_bp.route('/api/propostas/listar', methods=['GET'])
def listar_propostas():
    try:
        propostas = []
        
        for arquivo in os.listdir(FORNECEDOR_DIR):
            if arquivo.endswith('.json'):
                with open(os.path.join(FORNECEDOR_DIR, arquivo), 'r', encoding='utf-8') as f:
                    dados = json.load(f)
                    propostas.append({
                        'protocolo': dados.get('protocolo'),
                        'dataEnvio': dados.get('dataEnvio'),
                        'fornecedor': dados.get('dadosCadastrais', {}).get('razaoSocial'),
                        'processo': dados.get('processo', {}).get('numero'),
                        'valorTotal': dados.get('propostaComercial', {}).get('valorTotal'),
                        'status': dados.get('status')
                    })
        
        # Ordenar por data de envio (mais recente primeiro)
        propostas.sort(key=lambda x: x.get('dataEnvio', ''), reverse=True)
        
        return jsonify({
            'propostas': propostas,
            'total': len(propostas)
        })
        
    except Exception as e:
        return jsonify({
            'erro': f'Erro ao listar propostas: {str(e)}'
        }), 500

